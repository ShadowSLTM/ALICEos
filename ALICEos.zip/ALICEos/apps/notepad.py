"""
Bloc-notes d'ALICEos.
Édite un fichier texte du système de fichiers virtuel, ou un document volant
non encore rattaché à un fichier si ouvert depuis le menu Démarrer.
"""

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QPushButton, QLabel


class Notepad(QWidget):
    def __init__(self, vfs, notifier=None, folder_path=None, filename=None):
        super().__init__()
        self.vfs = vfs
        self.notifier = notifier
        self.folder_path = folder_path
        self.filename = filename

        layout = QVBoxLayout(self)
        toolbar = QHBoxLayout()
        self.title_label = QLabel(filename or "Document sans titre")
        self.title_label.setStyleSheet("font-weight: 600;")
        toolbar.addWidget(self.title_label, 1)
        save_btn = QPushButton("Enregistrer")
        save_btn.clicked.connect(self.save)
        toolbar.addWidget(save_btn)
        layout.addLayout(toolbar)

        self.editor = QTextEdit()
        if folder_path is not None and filename:
            node = self.vfs.resolve(folder_path + [filename])
            if node and not node.is_dir:
                self.editor.setPlainText(node.content)
        layout.addWidget(self.editor)

    def save(self):
        if self.folder_path is not None and self.filename:
            self.vfs.write_file(self.folder_path, self.filename, self.editor.toPlainText())
            if self.notifier:
                self.notifier.notify("Enregistré", f"« {self.filename} » a été enregistré.")
        else:
            if self.notifier:
                self.notifier.notify("Astuce", "Ouvre ce document depuis l'explorateur pour l'enregistrer sur un fichier.")
